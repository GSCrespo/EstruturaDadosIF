#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct estadio{

    int valor;
    struct estadio *proximo;

}ES;


void inserir_fila(ES **fila,int num){
    
    ES *novo = malloc(sizeof(ES));

    if(novo != NULL){
        novo->valor = num;
        novo->proximo = NULL;
    }else{
        // erro ao alocar memoria
        printf("ERRO AO ALOCAR\n");
        return;
    }

    if(*fila == NULL){ // se o  conteudo apontado por fila for null, a fila esta vazia

        *fila = novo;
    }else{
        ES *aux = *fila; // aux ponteiro p inicio da fila

        while(aux->proximo != NULL){

            aux = aux->proximo; // andando com a fila ate chegar na ultima posicao da fila
        }
        aux->proximo = novo; // cheguei na ultima posicao da fila e inseri o novo nó (ponteiro novo que sera adicionado)
    }

    
 }

void retirar_fila(ES **fila,int valor){
    ES *anterior = NULL;
    ES *atual = *fila;
    
    if(atual != NULL){

        while(atual != NULL){

            if(atual->valor == valor){
                if(anterior == NULL){
                    *fila = atual->proximo;

                }else{
                    anterior->proximo = atual->proximo;
                }
                free(atual);
                return;
            }
            anterior = atual;
            atual = atual->proximo;
            
        }
    }
}

void imprimir(ES *fila){

    
    while(fila){
        printf("%d ",fila->valor);
        fila = fila->proximo;
    }
    
}

int main(int argc, char const *argv[])
{
    ES *fila = NULL; // inicia a fila como null
    ES *fila_aux = NULL;
    int num_pessoas,identificador = 0;
    // identificador é o valor que devera ser armazenado no campo (valor) da struct
    // num_pessoas representa a quantidade de pessoas na fila, possivelmente é o ponteiro inicial da fila

    int num_deixaram_fila, valor_deixou_fila = 0;
    //printf("Informe o num d pessoas na fila\n");
    scanf("%d",&num_pessoas);
    // recebe o numero de pessoas na fila

    //printf("Informe os identificadores.\n");
    for(int i = 0; i < num_pessoas; i++){
        scanf("%d",&identificador);
        inserir_fila(&fila,identificador);
        
    }
    //imprimir(fila);

    // recebe quantas pessoas deixaram a fila
    scanf("%d",&num_deixaram_fila);

    for(int i = 0; i < num_deixaram_fila; i++){
        scanf("%d",&valor_deixou_fila);
        retirar_fila(&fila,valor_deixou_fila);
        
    }
    printf("\n");
    imprimir(fila);
    
    

    return 0;
}



